
<template>
<h1>This is home page</h1>
<a class="btn btn-danger" href="">delete</a>
</template>
