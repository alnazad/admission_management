<script setup>
import '@/assets/vendors/typicons/typicons.css'
import '@/assets/vendors/css/vendor.bundle.base.css'
import '@/assets/css/vertical-layout-light/style.css'
import '@/assets/images/favicon.png'
import '@/assets/vendors/chart.js/Chart.min.js'
import '@/assets/vendors/font-awesome/css/font-awesome.min.css'
 

  import Content from '../components/Content.vue';
</script>
<template>
  <Content/>
</template>