<template>
    <h1>
        Eligible Student List
    </h1>
</template>