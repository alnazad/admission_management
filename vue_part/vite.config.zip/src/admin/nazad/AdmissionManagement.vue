<template>
    <img height="600px" src="@/assets/images/proje.jpg" alt="not found">
</template>