<template>
    <h1>
        Admission Fee Management
    </h1>
</template>