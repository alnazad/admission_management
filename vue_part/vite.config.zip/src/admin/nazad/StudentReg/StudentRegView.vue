<template>
    <h1>
        Student Registration
    </h1>
</template>