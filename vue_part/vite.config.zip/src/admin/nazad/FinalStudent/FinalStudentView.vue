<template>
    <h1>
        Final Student Approval
    </h1>
</template>