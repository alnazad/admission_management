<template>
    <footer class="footer">
        <div class="card">
            <div class="card-body">
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"><a href="https://www.bootstrapdash.com/" class="text-muted"
                            target="_blank"></a></span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center text-muted">Developed By
                        <a href="https://www.bootstrapdash.com/" class="text-muted" target="_blank">Mohammad Abdullah Al Nazad</a></span>
                </div>
            </div>
        </div>
    </footer>
</template>