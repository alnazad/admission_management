<template>
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div style="background-color: #005b5b;" class="col-12 row">
            <div style="margin-left: 30px;" class="col-lg-2 col-2">
                <img style="margin-left: 50px;padding: 5px;" src="@/assets/images/faces/Gov.png" height="100px" alt="">
                <div style="color: white;font-family: 'typicons';font-size: 20px;">Ministry of Social Welfare</div>
            </div>
            <div class="col-10" style="text-align: center;color: white;margin-left: 10%;margin-top: -110px;">
                <div style="font-family: 'typicons';font-weight: bold;font-size: 25px;">Welcome to</div>
                <div style="font-family: 'typicons';font-weight: bold;font-size: 35px;">Integrated Digital Service Delivery Platform for Ministry of Social Welfare</div>
                <div style="font-family: 'typicons';font-size: 25px;">Disability School & Education Management System</div>
            </div>
        </div>
        <div style="background-color:#c4d59f; height: 60px;" class="col-12">
            <div class="row">
                <div class="col-3" style="">
                    <a style="text-decoration: none;"  href="">
                        <div onmouseover="this.style.background='rgb(214 226 190)'"onmouseout="this.style.background='#c4d59f'" style="padding-bottom: 16px;padding-top: 10px;font-weight: bold;font-size: large;text-align: center; color:black;width: 378px;margin-left: -23px;border:solid;border-color:#0000001f">Institute Management</div>
                    </a>
                    
                </div>
                <div class="col-3">
                    <router-link style="text-decoration: none;" :to="{name:'AdmissionManagement'}">
                        <div onmouseover="this.style.background='rgb(214 226 190)'"onmouseout="this.style.background='#c4d59f'" style="padding-bottom: 15px;padding-top: 11px;font-weight: bold;font-size: large;text-align: center; color:black;width: 379px;margin-left: -18px;border:solid;border-color:#0000001f">Admission Management</div>
                    </router-link>
                    
                </div>
                <div class="col-3">
                    <a style="text-decoration: none;" href="">
                        <div onmouseover="this.style.background='rgb(214 226 190)'"onmouseout="this.style.background='#c4d59f'" style="padding-bottom: 15px;padding-top: 10px;font-weight: bold;font-size: large;text-align: center; color:black;width: 378px;margin-left: -10px;border:solid;border-color:#0000001f">Student Management</div>
                    </a>
                    
                </div>
                <div class="col-3">
                    <a style="text-decoration: none;" href="">
                        <div onmouseover="this.style.background='rgb(214 226 190)'"onmouseout="this.style.background='#c4d59f'" style="padding-bottom: 15px;padding-top: 10px;font-weight: bold;font-size: large;text-align: center; color:black;width: 372px;margin-left: -3px;border:solid;border-color:#0000001f">Exam & Result Management</div>
                    </a>
                    
                </div>
            </div>
        </div>
    </nav>

</template>